import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  ReactNode,
} from 'react';
import { AppState, Platform } from 'react-native';
import { AppError, messageFor, toAppError } from '../core/errors';
import { RepeatMode, Track } from '../core/types';
import { flushWrites, readJson, writeJsonDebounced, STORAGE_KEYS } from '../core/storage';
import { playbackEngine, IDLE_STATUS, PlaybackStatus } from '../playback/PlaybackEngine';
import { Queue, QueueSnapshot, EMPTY_QUEUE } from '../playback/queue';
import { preloader } from '../playback/preload';
import { endpointSource } from '../providers/stream/StreamResolver';
import { LibraryService } from '../services/LibraryService';
import { MusicService } from '../services/MusicService';

type PlayerContextType = {
  // --- the original mock API, unchanged so existing screens keep working ---
  currentTrack: Track | null;
  isPlaying: boolean;
  playTrack: (track: Track, context?: { tracks?: Track[]; label?: string }) => void;
  togglePlayPause: () => void;
  // --- everything the real player adds ---
  isLoading: boolean;
  isBuffering: boolean;
  error: string | null;
  clearError: () => void;
  retry: () => void;
  duration: number;
  volume: number;
  setVolume: (v: number) => void;
  seekTo: (seconds: number) => void;
  /** Jump relative to the current position. Negative rewinds. */
  seekBy: (deltaSeconds: number) => void;
  next: () => void;
  previous: () => void;
  hasNext: boolean;
  hasPrevious: boolean;
  queue: Track[];
  upcoming: Track[];
  queueContext: string;
  addToQueue: (tracks: Track | Track[]) => void;
  playNext: (tracks: Track | Track[]) => void;
  removeFromQueue: (trackId: string) => void;
  reorderQueue: (from: number, to: number) => void;
  /** Commit a new order (by track ids) for the upcoming portion of the queue. */
  reorderUpcoming: (ids: string[]) => void;
  clearQueue: () => void;
  jumpTo: (trackId: string) => void;
  shuffle: boolean;
  toggleShuffle: () => void;
  repeat: RepeatMode;
  cycleRepeat: () => void;
  isReady: boolean;
  canPlayCurrent: boolean;
};

/**
 * How long a track must actually play before it counts as a listen.
 *
 * Tapping a track and skipping it immediately is not listening, so history is
 * gated on real playback rather than on intent. Short tracks use a proportion
 * instead, so a 30s clip is not excluded by a fixed threshold.
 */
const HISTORY_MIN_SECONDS = 20;
const HISTORY_MIN_RATIO = 0.25;

/** How many unplayable tracks in a row we step over before giving up. */
const MAX_AUTO_SKIPS = 3;

const PlayerContext = createContext<PlayerContextType | undefined>(undefined);

/**
 * Progress lives in its own context because it updates ~4x a second. Screens
 * that only need the current track never re-render on a position tick.
 */
const ProgressContext = createContext<{ position: number; duration: number }>({
  position: 0,
  duration: 0,
});

export const PlayerProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const queueRef = useRef(new Queue());
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [status, setStatus] = useState<PlaybackStatus>(IDLE_STATUS);

  /**
   * Mirror of `status` for callbacks that only READ it.
   *
   * Position ticks ~4x a second. A callback that lists status.position in its
   * deps is rebuilt just as often, and because these callbacks sit in the
   * context value, that rebuilt the whole value 4x a second -- re-rendering
   * every screen using usePlayer and undoing the progress isolation.
   */
  const statusRef = useRef<PlaybackStatus>(IDLE_STATUS);
  statusRef.current = status;

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [queueVersion, setQueueVersion] = useState(0);
  const [volume, setVolumeState] = useState(1);

  /** Cancels an in-flight load when the user starts another one. */
  const loadAbort = useRef<AbortController | null>(null);
  /** Identifies the newest load so stale async work can bail out. */
  const loadId = useRef(0);
  /** The track we most recently attempted, for retry(). */
  const lastAttempt = useRef<{ track: Track; position: number } | null>(null);
  /** Which track the in-flight load belongs to, so we never abort our own. */
  const loadingTrackId = useRef<string | null>(null);
  /**
   * Consecutive tracks auto-skipped because they would not play. Bounded so a
   * queue full of dead videos stops instead of racing to the end.
   */
  const autoSkips = useRef(0);
  /** Load id whose listen has already been written to history. */
  /** Track id a listen has already been logged for — NOT the load id: a
   * same-track reload (double-tap on the currently playing row, re-selecting
   * it from the queue) must not reopen the history-logging window, or the
   * position-threshold effect below fires again and writes a duplicate entry
   * for a listen that never actually restarted. */
  const historyWrittenFor = useRef<string | null>(null);

  const bumpQueue = useCallback(() => setQueueVersion((v) => v + 1), []);

  // ---- persistence ------------------------------------------------------

  const persistQueue = useCallback(() => {
    writeJsonDebounced(STORAGE_KEYS.queue, queueRef.current.snapshot(), 600);
  }, []);

  // ---- loading a track --------------------------------------------------

  const loadCurrent = useCallback(
    async (options: { autoPlay?: boolean; startPosition?: number } = {}) => {
      const track = queueRef.current.current;
      if (!track) {
        setCurrentTrack(null);
        setIsLoading(false);
        playbackEngine.stop();
        return;
      }

      const id = ++loadId.current;
      // Only abort the previous load -- and only reopen the history-logging
      // window -- if this is genuinely a DIFFERENT track. A same-track reload
      // (double-tap on the playing row, re-picking it from the queue) joins
      // the existing in-flight resolve and must not look like a fresh listen.
      if (loadingTrackId.current !== track.id) {
        loadAbort.current?.abort();
        historyWrittenFor.current = null;
      }
      const controller = new AbortController();
      loadAbort.current = controller;
      loadingTrackId.current = track.id;

      const preloadedThis = preloader.pending === track.id;

      // Stop warming anything that is no longer next -- but if we were warming
      // THIS track, adopt that request instead of aborting it: resolveStream
      // below will be handed the very same in-flight promise.
      preloader.adopt(track.id);

      if (__DEV__) {
        console.log('[playback] load', track.title, '| preloaded:', preloadedThis);
      }

      setCurrentTrack(track);
      setError(null);
      setIsLoading(true);
      lastAttempt.current = { track, position: options.startPosition ?? 0 };

      try {
        const stream = await MusicService.resolveStream(track, controller.signal);
        if (id !== loadId.current) return; // superseded by a newer load
        await playbackEngine.load(track, stream, options);
        if (id !== loadId.current) return;

        setIsLoading(false);
        autoSkips.current = 0;
        loadingTrackId.current = null;
        if (__DEV__) console.log('[playback] started', track.title);
        LibraryService.recordPlay(track);
        // Warm exactly one track ahead, so pressing skip is instant.
        preloader.schedule(queueRef.current.peekNext());
      } catch (e) {
        if (id !== loadId.current) return;
        // Always leave the loading state, whatever went wrong.
        setIsLoading(false);
        loadingTrackId.current = null;

        const err = toAppError(e, 'playback_failed');
        if (__DEV__) console.log('[playback] FAILED', track.title, '|', err.kind, '|', err.detail ?? '');

        // A dead stream URL should not be reused on retry.
        if (err.kind !== 'network' && err.kind !== 'timeout') {
          MusicService.invalidateStream(track);
        }

        // A track that simply cannot play should not strand the queue: step
        // over it and keep going. Network failures are NOT skipped -- the
        // next track would fail identically, so the error is shown instead.
        const skippable =
          err.kind === 'track_unavailable' ||
          err.kind === 'region_restricted' ||
          err.kind === 'source_unavailable';
        if (skippable && autoSkips.current < MAX_AUTO_SKIPS && queueRef.current.hasNext) {
          autoSkips.current += 1;
          if (__DEV__) console.log('[playback] auto-skip', autoSkips.current, 'past', track.title);
          queueRef.current.next(false);
          bumpQueue();
          persistQueue();
          void loadCurrent({ autoPlay: true });
          return;
        }

        autoSkips.current = 0;
        setError(messageFor(err));
      }
    },
    [bumpQueue, persistQueue]
  );

  // ---- engine wiring ----------------------------------------------------

  useEffect(() => {
    playbackEngine.on('onStatus', (s) => setStatus(s));
    playbackEngine.on('onComplete', () => {
      // `auto` so repeat-one replays rather than advances.
      const nextTrack = queueRef.current.next(true);
      bumpQueue();
      persistQueue();
      if (!nextTrack) {
        // End of queue: optionally keep going with related tracks.
        void extendWithRelated();
        return;
      }
      void loadCurrent({ autoPlay: true });
    });
    playbackEngine.on('onError', (e) => {
      setIsLoading(false);
      setError(messageFor(e instanceof AppError ? e : toAppError(e, 'playback_failed')));
    });
    return () => {
      preloader.cancel();
      void playbackEngine.release();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const extendWithRelated = useCallback(async () => {
    const settings = LibraryService.getSettings();
    const last = queueRef.current.current;
    if (!settings.autoplayRelated || !last) return;
    try {
      const related = await MusicService.getRelated(last);
      const fresh = related.filter(
        (t) => !queueRef.current.items.some((q) => q.id === t.id)
      );
      if (!fresh.length) return;
      queueRef.current.add(fresh.slice(0, 20));
      const nextTrack = queueRef.current.next(false);
      bumpQueue();
      persistQueue();
      if (nextTrack) void loadCurrent({ autoPlay: true });
    } catch {
      // Autoplay is a convenience; silence is the right failure mode.
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---- startup: restore library, settings, queue and position -----------

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        await Promise.all([MusicService.init(), LibraryService.load()]);
        if (cancelled) return;

        const settings = LibraryService.getSettings();
        endpointSource.setEndpoints(settings.resolverEndpoints);
        playbackEngine.setVolume(settings.volume);
        setVolumeState(settings.volume);
        void playbackEngine.configure();

        const snapshot = await readJson<QueueSnapshot>(STORAGE_KEYS.queue, EMPTY_QUEUE);
        if (cancelled) return;
        if (snapshot.tracks?.length) {
          queueRef.current.restore(snapshot);
          bumpQueue();
          const restored = queueRef.current.current;
          if (restored) {
            // Restore the track and its position, but never auto-play on
            // launch -- starting audio unprompted is hostile.
            const saved = await LibraryService.getSavedPlayback();
            if (cancelled) return;
            setCurrentTrack(restored);
            lastAttempt.current = {
              track: restored,
              position: saved.trackId === restored.id ? saved.position : 0,
            };
          }
        }
      } catch {
        // A corrupt restore must never prevent the app from starting.
      } finally {
        if (!cancelled) setIsReady(true);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---- persist playback position ---------------------------------------
  // Position ticks ~4x a second but is persisted in whole seconds, so only
  // react when the second actually changes.
  const positionSecond = Math.floor(status.position);
  useEffect(() => {
    if (!currentTrack) return;
    LibraryService.savePlayback(currentTrack.id, positionSecond);
    // A listen is logged once, mid-playback, not on tap and not on finish --
    // so skipping away early leaves no trace, and a track abandoned near the
    // end still counts.
    if (historyWrittenFor.current === currentTrack.id) return;
    const trackDuration = status.duration || currentTrack.duration || 0;
    const threshold = Math.min(
      HISTORY_MIN_SECONDS,
      trackDuration > 0 ? trackDuration * HISTORY_MIN_RATIO : HISTORY_MIN_SECONDS
    );
    if (positionSecond >= threshold && positionSecond > 0) {
      historyWrittenFor.current = currentTrack.id;
      LibraryService.recordListen(currentTrack);
      if (__DEV__) console.log('[history] logged', currentTrack.title);
    }
  }, [currentTrack, positionSecond, status.duration]);

  // Flush pending writes when the app goes to the background or the tab closes.
  useEffect(() => {
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'background' || 'inactive' === state) void flushWrites();
    });
    let onHide: (() => void) | undefined;
    if (Platform.OS === 'web' && typeof window !== 'undefined') {
      onHide = () => void flushWrites();
      window.addEventListener('pagehide', onHide);
    }
    return () => {
      sub.remove();
      if (onHide && typeof window !== 'undefined') {
        window.removeEventListener('pagehide', onHide);
      }
    };
  }, []);

  // ---- actions ----------------------------------------------------------

  const playTrack = useCallback(
    (track: Track, context?: { tracks?: Track[]; label?: string }) => {
      const list = context?.tracks?.length ? context.tracks : [track];
      const startIndex = Math.max(
        0,
        list.findIndex((t) => t.id === track.id)
      );
      queueRef.current.setTracks(list, startIndex, context?.label ?? '');
      bumpQueue();
      persistQueue();
      void loadCurrent({ autoPlay: true });
    },
    [bumpQueue, loadCurrent, persistQueue]
  );

  const togglePlayPause = useCallback(() => {
    const track = queueRef.current.current ?? currentTrack;
    if (!track) return;
    // Restored-but-never-loaded track: the first press starts it.
    if (playbackEngine.trackId !== track.id) {
      if (!queueRef.current.current) {
        queueRef.current.setTracks([track], 0, '');
        bumpQueue();
      }
      void loadCurrent({
        autoPlay: true,
        startPosition: lastAttempt.current?.position ?? 0,
      });
      return;
    }
    if (status.isPlaying) playbackEngine.pause();
    else playbackEngine.play();
  }, [bumpQueue, currentTrack, loadCurrent, status.isPlaying]);

  const next = useCallback(() => {
    const nextTrack = queueRef.current.next(false);
    bumpQueue();
    persistQueue();
    if (!nextTrack) {
      void extendWithRelated();
      return;
    }
    void loadCurrent({ autoPlay: true });
  }, [bumpQueue, extendWithRelated, loadCurrent, persistQueue]);

  const previous = useCallback(() => {
    // Standard behaviour: restart the track if we are more than 3s in.
    if (statusRef.current.position > 3) {
      void playbackEngine.seekTo(0);
      return;
    }
    queueRef.current.previous();
    bumpQueue();
    persistQueue();
    void loadCurrent({ autoPlay: true });
  }, [bumpQueue, loadCurrent, persistQueue]);

  const seekTo = useCallback((seconds: number) => {
    void playbackEngine.seekTo(seconds);
  }, []);

  /**
   * Relative seek, matching the +/-10s the lock screen offers.
   * Clamped to the track so it cannot run past either end.
   */
  const seekBy = useCallback(
    (deltaSeconds: number) => {
      const { duration, position } = statusRef.current;
      const total = duration || currentTrack?.duration || 0;
      const target = position + deltaSeconds;
      const clamped = total > 0 ? Math.min(total, Math.max(0, target)) : Math.max(0, target);
      void playbackEngine.seekTo(clamped);
    },
    [currentTrack?.duration]
  );

  const setVolume = useCallback((v: number) => {
    const clamped = Math.max(0, Math.min(1, v));
    playbackEngine.setVolume(clamped);
    setVolumeState(clamped);
    LibraryService.updateSettings({ volume: clamped });
  }, []);

  const retry = useCallback(() => {
    const attempt = lastAttempt.current;
    if (!attempt) return;
    setError(null);
    MusicService.invalidateStream(attempt.track);
    void loadCurrent({ autoPlay: true, startPosition: attempt.position });
  }, [loadCurrent]);

  const clearError = useCallback(() => setError(null), []);

  // ---- queue operations -------------------------------------------------

  const addToQueue = useCallback(
    (tracks: Track | Track[]) => {
      const wasEmpty = queueRef.current.length === 0;
      queueRef.current.add(tracks);
      bumpQueue();
      persistQueue();
      if (wasEmpty) void loadCurrent({ autoPlay: true });
    },
    [bumpQueue, loadCurrent, persistQueue]
  );

  const playNextInQueue = useCallback(
    (tracks: Track | Track[]) => {
      const wasEmpty = queueRef.current.length === 0;
      queueRef.current.playNext(tracks);
      bumpQueue();
      persistQueue();
      if (wasEmpty) void loadCurrent({ autoPlay: true });
      else preloader.schedule(queueRef.current.peekNext());
    },
    [bumpQueue, loadCurrent, persistQueue]
  );

  const removeFromQueue = useCallback(
    (trackId: string) => {
      const removedCurrent = queueRef.current.remove(trackId);
      bumpQueue();
      persistQueue();
      // Removing the playing track slides the next one into its place.
      if (removedCurrent) {
        if (queueRef.current.current) void loadCurrent({ autoPlay: true });
        else {
          playbackEngine.stop();
          setCurrentTrack(null);
        }
      }
    },
    [bumpQueue, loadCurrent, persistQueue]
  );

  const reorderQueue = useCallback(
    (from: number, to: number) => {
      queueRef.current.reorder(from, to);
      bumpQueue();
      persistQueue();
    },
    [bumpQueue, persistQueue]
  );

  /** Commit the drag-to-reorder sheet's new upcoming order (by track ids). */
  const reorderUpcoming = useCallback(
    (ids: string[]) => {
      queueRef.current.reorderUpcoming(ids);
      bumpQueue();
      persistQueue();
    },
    [bumpQueue, persistQueue]
  );

  const clearQueue = useCallback(() => {
    queueRef.current.clearUpcoming();
    bumpQueue();
    persistQueue();
  }, [bumpQueue, persistQueue]);

  const jumpTo = useCallback(
    (trackId: string) => {
      const track = queueRef.current.jumpTo(trackId);
      if (!track) return;
      bumpQueue();
      persistQueue();
      void loadCurrent({ autoPlay: true });
    },
    [bumpQueue, loadCurrent, persistQueue]
  );

  const toggleShuffle = useCallback(() => {
    queueRef.current.toggleShuffle();
    bumpQueue();
    persistQueue();
    preloader.schedule(queueRef.current.peekNext());
  }, [bumpQueue, persistQueue]);

  const cycleRepeat = useCallback(() => {
    queueRef.current.cycleRepeat();
    bumpQueue();
    persistQueue();
  }, [bumpQueue, persistQueue]);

  // ---- context values ---------------------------------------------------

  const queueSnapshot = useMemo(
    () => ({
      items: queueRef.current.items,
      upcoming: queueRef.current.upcoming,
      context: queueRef.current.context,
      shuffle: queueRef.current.shuffle,
      repeat: queueRef.current.repeat,
      hasNext: queueRef.current.hasNext,
      hasPrevious: queueRef.current.hasPrevious,
    }),
    // queueVersion is the explicit invalidation signal for the mutable Queue.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [queueVersion]
  );

  // Prefer the source-reported duration, falling back to provider metadata
  // so the scrubber is usable before the stream reports one.
  const duration = status.duration || currentTrack?.duration || 0;

  const value = useMemo<PlayerContextType>(
    () => ({
      currentTrack,
      isPlaying: status.isPlaying,
      playTrack,
      togglePlayPause,
      isLoading,
      isBuffering: status.isBuffering,
      error,
      clearError,
      retry,
      duration,
      volume,
      setVolume,
      seekTo,
      seekBy,
      next,
      previous,
      hasNext: queueSnapshot.hasNext,
      hasPrevious: queueSnapshot.hasPrevious,
      queue: queueSnapshot.items,
      upcoming: queueSnapshot.upcoming,
      queueContext: queueSnapshot.context,
      addToQueue,
      playNext: playNextInQueue,
      removeFromQueue,
      reorderQueue,
      reorderUpcoming,
      clearQueue,
      jumpTo,
      shuffle: queueSnapshot.shuffle,
      toggleShuffle,
      repeat: queueSnapshot.repeat,
      cycleRepeat,
      isReady,
      canPlayCurrent: currentTrack ? MusicService.canPlay(currentTrack) : false,
    }),
    [
      currentTrack,
      status.isPlaying,
      status.isBuffering,
      playTrack,
      togglePlayPause,
      isLoading,
      error,
      clearError,
      retry,
      duration,
      volume,
      setVolume,
      seekTo,
      seekBy,
      next,
      previous,
      queueSnapshot,
      addToQueue,
      playNextInQueue,
      removeFromQueue,
      reorderQueue,
      reorderUpcoming,
      clearQueue,
      jumpTo,
      toggleShuffle,
      cycleRepeat,
      isReady,
    ]
  );

  const progressValue = useMemo(
    () => ({ position: status.position, duration }),
    [status.position, duration]
  );

  return (
    <PlayerContext.Provider value={value}>
      <ProgressContext.Provider value={progressValue}>{children}</ProgressContext.Provider>
    </PlayerContext.Provider>
  );
};

export const usePlayer = () => {
  const context = useContext(PlayerContext);
  if (context === undefined) {
    throw new Error('usePlayer must be used within a PlayerProvider');
  }
  return context;
};

/** Subscribe to playback position without re-rendering on every other change. */
export const useProgress = () => useContext(ProgressContext);
